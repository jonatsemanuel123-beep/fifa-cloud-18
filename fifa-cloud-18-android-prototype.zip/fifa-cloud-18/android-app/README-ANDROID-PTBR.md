# FIFA Cloud 18 — aplicativo Android (protótipo)

Este projeto adiciona um aplicativo Android em formato APK que abre o cliente web do FIFA Cloud 18 em tela cheia, na horizontal.

## O que já está incluído
- Projeto Android Studio (Java + Gradle).
- WebView em tela cheia, orientação horizontal e tela ligada durante o uso.
- Cliente web copiado para dentro do APK durante a compilação.
- Workflow do GitHub Actions para gerar `app-debug.apk` sem precisar instalar Android Studio no celular.

## O que ainda não está pronto
- O APK é apenas o cliente. Ele não contém FIFA 18 nem servidor de jogos.
- O servidor de sinalização e o agente de streaming ainda precisam de ajustes e testes reais.
- O agente Windows atual é apenas um protótipo; para nuvem, ele precisa rodar em uma máquina virtual Windows com GPU em um provedor compatível.
- Áudio, controle Bluetooth completo, autenticação, TURN e gestão de sessões ainda precisam ser implementados/testados.
- Não publique um servidor de sinalização aberto na internet: antes disso, implemente autenticação, TLS, limites de uso e isolamento de salas.

## Como gerar o APK usando somente o celular
1. Crie uma conta no GitHub, se ainda não tiver.
2. Crie um repositório novo e envie os arquivos desta pasta do projeto.
3. No GitHub, abra **Actions**.
4. Selecione **Build Android APK** e toque em **Run workflow**. Também compila automaticamente quando os arquivos relevantes são atualizados.
5. Quando terminar, abra a execução e baixe o artefato `fifa-cloud-18-debug-apk`.
6. Extraia o ZIP baixado para encontrar `app-debug.apk`.

O APK gerado é de depuração (debug), adequado para testes. Não é uma versão publicada na Play Store.

## Abrir no Android Studio (opcional)
Abra a pasta `android-app` no Android Studio e execute a tarefa `assembleDebug`.

## Configuração do servidor
Ao abrir o aplicativo, informe o endereço WebSocket seguro do servidor, por exemplo `wss://seu-dominio.example`. Para produção, use HTTPS/WSS com certificado válido. O endereço de exemplo não é um servidor real.

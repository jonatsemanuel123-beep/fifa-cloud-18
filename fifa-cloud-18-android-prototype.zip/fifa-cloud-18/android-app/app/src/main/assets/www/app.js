const $ = (id) => document.getElementById(id);
let socket, pc, localStream, role = "player";
const savedSignalUrl = localStorage.getItem("fifa18.signalUrl");
if (savedSignalUrl) $("signalUrl").value = savedSignalUrl;
const pressed = new Set();

function setStatus(text) { $("status").textContent = text; }
function send(message) {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}
function room() { return $("room").value.trim(); }

async function connect(nextRole) {
  const url = $("signalUrl").value.trim();
  localStorage.setItem("fifa18.signalUrl", url);
  if (!url.startsWith("wss://") && !url.startsWith("ws://")) {
    alert("Informe o endereço ws:// ou wss:// do servidor.");
    return;
  }
  role = nextRole;
  socket = new WebSocket(url);
  socket.onopen = () => {
    send({ type: "join", room: room(), role });
    setStatus("Conectando...");
  };
  socket.onmessage = async (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === "joined") setStatus(`Conectado • ${role}`);
    if (msg.type === "peer-joined" && role === "host") await makeOffer();
    if (msg.type === "offer" && role === "player") {
      await ensurePeer();
      await pc.setRemoteDescription(msg.description);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      send({ type: "answer", description: pc.localDescription });
    }
    if (msg.type === "answer" && role === "host") await pc.setRemoteDescription(msg.description);
    if (msg.type === "ice" && msg.candidate && pc) {
      try {
        await pc.addIceCandidate({
          candidate: msg.candidate,
          sdpMid: msg.sdpMid ?? null,
          sdpMLineIndex: msg.sdpMLineIndex ?? null
        });
      } catch (e) { console.warn(e); }
    }
    if (msg.type === "input" && role === "host") {
      // Recebe comandos. Um agente nativo deverá convertê-los em entrada do jogo.
      console.log("Game input:", msg.key, msg.down);
    }
  };
  socket.onclose = () => setStatus("Desconectado");
  socket.onerror = () => setStatus("Erro de conexão");
}

async function ensurePeer() {
  if (pc) return;
  pc = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
  });
  pc.onicecandidate = (e) => {
    if (e.candidate) send({ type: "ice", candidate: e.candidate });
  };
  pc.ontrack = (e) => {
    $("remoteVideo").srcObject = e.streams[0];
    $("placeholder").hidden = true;
  };
  pc.onconnectionstatechange = () => setStatus(`Streaming • ${pc.connectionState}`);
}

async function startHost() {
  await connect("host");
  // Protótipo: compartilhamento manual da tela pelo navegador no PC.
  localStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
  await ensurePeer();
  localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
}
async function makeOffer() {
  if (!pc) await ensurePeer();
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  send({ type: "offer", description: pc.localDescription });
}
function input(key, down) { send({ type: "input", key, down, room: room() }); }

document.querySelectorAll("[data-key]").forEach(button => {
  const key = button.dataset.key;
  button.addEventListener("pointerdown", e => {
    e.preventDefault(); button.setPointerCapture(e.pointerId);
    pressed.add(key); input(key, true);
  });
  const release = e => {
    e.preventDefault(); pressed.delete(key); input(key, false);
  };
  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("lostpointercapture", () => {
    if (pressed.has(key)) { pressed.delete(key); input(key, false); }
  });
});

window.addEventListener("gamepadconnected", () => $("gamepadState").textContent = "Controle detectado no Android/navegador");
window.addEventListener("gamepaddisconnected", () => $("gamepadState").textContent = "Controle desconectado");
// Gamepad API é consultada enquanto a página está ativa.
setInterval(() => {
  const pad = navigator.getGamepads?.()[0];
  if (!pad) return;
  pad.buttons.forEach((b, i) => {
    const key = `PAD_${i}`;
    if (b.pressed && !pressed.has(key)) { pressed.add(key); input(key, true); }
    if (!b.pressed && pressed.has(key)) { pressed.delete(key); input(key, false); }
  });
}, 50);

$("connect").onclick = () => connect("player");
$("host").onclick = () => startHost().catch(err => {
  console.error(err); alert(`Não foi possível iniciar o host: ${err.message}`);
});
$("fullscreen").onclick = () => $("remoteVideo").requestFullscreen?.();

if ("serviceWorker" in navigator) {
  // Service worker is optional in this starter; app remains usable without offline caching.
}

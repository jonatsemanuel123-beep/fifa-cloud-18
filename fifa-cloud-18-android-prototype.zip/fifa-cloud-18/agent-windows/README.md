# Agente Windows — FIFA Cloud 18

Este agente é um protótipo de host Windows:
- captura a área de trabalho principal;
- publica vídeo por WebRTC usando `aiortc`;
- recebe eventos de botões e mapeia para teclas configuráveis;
- não executa comandos arbitrários recebidos pela rede.

## Requisitos
- Windows 10/11;
- Python 3.10 ou 3.11 (recomendado);
- FIFA 18 instalado legalmente e iniciado no PC/servidor;
- servidor de sinalização do projeto em execução;
- navegador Android/desktop com suporte a WebRTC.

## Instalação
Abra PowerShell nesta pasta:

```powershell
py -3.11 -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Configure o endereço e a sala:

```powershell
$env:FIFA_SIGNAL_URL = "wss://SEU-DOMINIO/signal"
$env:FIFA_ROOM = "fifa18-demo"
python agent.py
```

Para desenvolvimento local, use `ws://IP-DO-SERVIDOR:8080`. Em produção, use `wss://` atrás de proxy TLS.

No aplicativo web, informe a mesma URL e sala e clique em **Conectar para jogar**. O agente Windows atua como `host`; o navegador/Android atua como `player`.

## Mapeamento de teclas
Edite `KEY_MAP` em `agent.py` para corresponder às teclas configuradas no FIFA 18. O mapeamento inicial é apenas demonstrativo. O protótipo encaminha os botões virtuais como teclas; ainda não cria um controle Xbox virtual.

## Limitações importantes
- Captura a tela principal inteira; não captura áudio do sistema.
- O vídeo usa o encoder disponível no `aiortc`; desempenho depende do PC/servidor.
- STUN público é usado no cliente web. Para redes restritivas, configure um servidor TURN e adicione-o à configuração ICE do cliente e do agente.
- O servidor de sinalização inicial não tem autenticação. Não o exponha publicamente sem autenticação, TLS, limitação de taxa e salas privadas.
- Para um serviço cloud real, cada jogador precisa de uma VM isolada com GPU, sessão de jogo própria, TURN e agente supervisionado.
- Controles Bluetooth são lidos pelo Gamepad API no navegador, mas o protótipo web ainda encaminha somente os botões virtuais mapeados; suporte completo a gamepad precisa de um mapeador de botões e driver de gamepad virtual no Windows.

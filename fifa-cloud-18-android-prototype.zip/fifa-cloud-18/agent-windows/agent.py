import asyncio
import json
import os
import ctypes
from ctypes import wintypes

import mss
import numpy as np
import websockets
from PIL import Image
from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from av import VideoFrame

SIGNAL_URL = os.environ.get("FIFA_SIGNAL_URL", "ws://127.0.0.1:8080")
ROOM = os.environ.get("FIFA_ROOM", "fifa18-demo")
FPS = int(os.environ.get("FIFA_FPS", "30"))
MAX_WIDTH = int(os.environ.get("FIFA_WIDTH", "1280"))

# Keep this mapping aligned with the keyboard bindings configured in FIFA 18.
KEY_MAP = {
    "UP": "w", "DOWN": "s", "LEFT": "a", "RIGHT": "d",
    "A": "j", "B": "k", "X": "u", "Y": "i"
}

user32 = ctypes.WinDLL("user32", use_last_error=True)
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
MAP_VK = {name: ord(char.upper()) for name, char in KEY_MAP.items()}
held_keys = set()

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))
    ]

class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]

def key_event(vk: int, key_down: bool):
    flags = 0 if key_down else KEYEVENTF_KEYUP
    extra = ctypes.c_ulong(0)
    item = INPUT(type=INPUT_KEYBOARD)
    item.union.ki = KEYBDINPUT(vk, 0, flags, 0, ctypes.pointer(extra))
    user32.SendInput(1, ctypes.byref(item), ctypes.sizeof(INPUT))

def handle_input(message):
    key = message.get("key")
    down = bool(message.get("down"))
    if key not in MAP_VK:
        return
    vk = MAP_VK[key]
    if down and key not in held_keys:
        key_event(vk, True)
        held_keys.add(key)
    elif not down and key in held_keys:
        key_event(vk, False)
        held_keys.discard(key)

def release_all():
    for key in list(held_keys):
        key_event(MAP_VK[key], False)
        held_keys.discard(key)

class DesktopVideoTrack(VideoStreamTrack):
    """Captures the primary Windows desktop and publishes it as a WebRTC video track."""
    def __init__(self):
        super().__init__()
        self.sct = mss.mss()
        self.monitor = self.sct.monitors[1]

    async def recv(self):
        pts, time_base = await self.next_timestamp()
        shot = self.sct.grab(self.monitor)
        frame = np.asarray(shot)[:, :, :3]  # BGRA -> BGR
        image = Image.fromarray(frame[:, :, ::-1])  # BGR -> RGB

        if image.width > MAX_WIDTH:
            height = int(image.height * MAX_WIDTH / image.width)
            image = image.resize((MAX_WIDTH, height), Image.Resampling.BILINEAR)

        video = VideoFrame.from_image(image)
        video.pts = pts
        video.time_base = time_base
        await asyncio.sleep(max(0, 1 / max(1, FPS) - 0.001))
        return video

async def run():
    pc = RTCPeerConnection()
    pc.addTrack(DesktopVideoTrack())

    async with websockets.connect(SIGNAL_URL, max_size=2**20) as ws:
        await ws.send(json.dumps({"type": "join", "room": ROOM, "role": "host"}))
        print(f"[FIFA Cloud 18] Host conectado. Sala: {ROOM}")
        print("[FIFA Cloud 18] Deixe o FIFA 18 aberto em modo janela ou sem bordas.")

        async def send_ice(candidate):
            if candidate is not None:
                await ws.send(json.dumps({
                    "type": "ice",
                    "candidate": candidate.to_sdp(),
                    "sdpMid": candidate.sdpMid,
                    "sdpMLineIndex": candidate.sdpMLineIndex
                }))

        @pc.on("icecandidate")
        async def on_icecandidate(candidate):
            await send_ice(candidate)

        @pc.on("connectionstatechange")
        async def on_connectionstatechange():
            print("[WebRTC]", pc.connectionState)

        async def handle_signal(data):
            kind = data.get("type")
            if kind == "peer-joined":
                offer = await pc.createOffer()
                await pc.setLocalDescription(offer)
                await ws.send(json.dumps({
                    "type": "offer",
                    "description": {
                        "type": pc.localDescription.type,
                        "sdp": pc.localDescription.sdp
                    }
                }))
                print("[WebRTC] Oferta enviada ao jogador.")
            elif kind == "answer":
                desc = data.get("description", {})
                await pc.setRemoteDescription(RTCSessionDescription(
                    sdp=desc["sdp"], type=desc["type"]
                ))
                print("[WebRTC] Resposta recebida.")
            elif kind == "ice":
                # Candidate format is relayed by the browser client.
                from aiortc.sdp import candidate_from_sdp
                raw = data.get("candidate")
                if raw:
                    candidate = candidate_from_sdp(raw.split(":", 1)[-1])
                    candidate.sdpMid = data.get("sdpMid")
                    candidate.sdpMLineIndex = data.get("sdpMLineIndex")
                    await pc.addIceCandidate(candidate)
            elif kind == "input":
                handle_input(data)
            elif kind == "peer-left":
                release_all()
                print("[FIFA Cloud 18] Jogador desconectou.")

        try:
            async for raw in ws:
                try:
                    await handle_signal(json.loads(raw))
                except Exception as exc:
                    print("[Sinalização] Erro ao processar mensagem:", exc)
        finally:
            release_all()
            await pc.close()

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Este agente de entrada foi preparado para Windows.")
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        release_all()

const WebSocket = require("ws");
const http = require("http");

const PORT = Number(process.env.PORT || 8080);
const server = http.createServer((req, res) => {
  res.writeHead(200, { "content-type": "text/plain" });
  res.end("FIFA Cloud 18 signaling server\n");
});
const wss = new WebSocket.Server({ server });
const rooms = new Map();

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    const { type, room, role } = msg;
    if (type === "join") {
      if (!room || !["player", "host"].includes(role)) {
        send(ws, { type: "error", message: "Invalid room or role." });
        return;
      }
      ws.room = String(room).slice(0, 80);
      ws.role = role;
      if (!rooms.has(ws.room)) rooms.set(ws.room, new Set());
      rooms.get(ws.room).add(ws);
      send(ws, { type: "joined", room: ws.room, role });
      for (const peer of rooms.get(ws.room)) {
        if (peer !== ws) send(peer, { type: "peer-joined", role });
      }
      return;
    }

    // Relay WebRTC negotiation and controller input only within the joined room.
    if (!ws.room || !rooms.has(ws.room)) return;
    for (const peer of rooms.get(ws.room)) {
      if (peer !== ws && peer.readyState === WebSocket.OPEN) {
        send(peer, { ...msg, from: ws.role });
      }
    }
  });

  ws.on("close", () => {
    if (!ws.room || !rooms.has(ws.room)) return;
    const peers = rooms.get(ws.room);
    peers.delete(ws);
    for (const peer of peers) send(peer, { type: "peer-left" });
    if (peers.size === 0) rooms.delete(ws.room);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`FIFA Cloud 18 signaling server listening on :${PORT}`);
});

# FIFA Cloud 18 — starter

Protótipo inicial de cliente web responsivo, com layout instalável como PWA, botões touch, leitura básica de controle via Gamepad API e servidor WebSocket para sinalização WebRTC.

## O que já existe
- Interface responsiva para celular e desktop.
- Sala de conexão (room).
- Servidor WebSocket que encaminha mensagens de sinalização.
- Cliente WebRTC para receber vídeo.
- Modo host de teste que compartilha manualmente a tela do PC.
- Eventos dos botões virtuais e do Gamepad API encaminhados ao host.

## O que ainda NÃO existe
Este repositório não é um serviço de cloud gaming pronto. Ainda faltam:
1. Um servidor Windows com GPU e FIFA 18 instalado por meio de uma licença legítima.
2. Um agente nativo no servidor para capturar/encodar o jogo e publicar vídeo WebRTC sem compartilhamento manual.
3. Um agente de entrada para converter eventos recebidos em comandos de controle do jogo.
4. Autenticação, salas privadas, TURN, HTTPS/WSS, cotas e isolamento de sessões.
5. Testes de latência, áudio, reconexão e compatibilidade de controles.

O modo host atual é apenas uma prova de conceito: abre o seletor de compartilhamento do navegador. O navegador host recebe os eventos de controle no console, mas não os injeta no FIFA 18.

## Requisitos
- Node.js 20+
- Um domínio com HTTPS/WSS em produção (WebRTC e APIs de mídia exigem contexto seguro).
- Para o host de teste: navegador desktop compatível com `getDisplayMedia`.

## Executar o servidor de sinalização
```bash
npm install
npm start
```
Por padrão, escuta na porta 8080. Em produção, coloque atrás de um proxy TLS e use `wss://`.

## Servir o frontend
Sirva a pasta `web/` por HTTP durante desenvolvimento e HTTPS em produção. Por exemplo:
```bash
npx http-server web -p 5173
```
Abra a página no PC host e no Android player. Informe a URL pública do servidor WebSocket nos dois dispositivos e use o mesmo nome de sala. No PC, clique em "Transmitir tela (host)" e selecione a janela do jogo. No Android, clique em "Conectar para jogar".

## Próxima implementação recomendada
Criar um agente Windows em C# ou Rust com:
- captura de desktop/janela via Windows Graphics Capture ou Desktop Duplication;
- encoder H.264 por hardware (NVENC/AMF/QSV quando disponível);
- pipeline WebRTC com ICE/STUN/TURN;
- áudio de sistema;
- mapeamento configurável de gamepad e touchscreen para XInput;
- autenticação de sessão com tokens temporários.

Não exponha o servidor de sinalização diretamente à internet sem autenticação e TLS.


## Agente Windows (novo)
A pasta `agent-windows/` contém um protótipo em Python que captura a tela do Windows, publica vídeo via WebRTC e converte os botões virtuais em teclas configuráveis. Consulte `agent-windows/README.md`.

Limitações do protótipo: sem áudio do sistema, sem gamepad Xbox virtual e sem autenticação no servidor de sinalização. Não exponha o servidor à internet pública sem adicionar autenticação, TLS e TURN.


## Aplicativo Android (APK)

Veja `README-ANDROID-PTBR.md` e o projeto `android-app/`. O APK é um cliente Android; o jogo roda em um servidor Windows remoto com GPU. O workflow `.github/workflows/build-android.yml` pode compilar o APK pelo GitHub Actions.
